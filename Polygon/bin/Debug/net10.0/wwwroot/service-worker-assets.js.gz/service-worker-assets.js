self.assetsManifest = {
  "version": "LR20Bri6",
  "assets": [
    {
      "hash": "sha256-A8e6zZwhOqf7lDQqbbCYcAUv4wGE9aQxOo4WyYxR//0=",
      "url": "_content/Microsoft.DotNet.HotReload.WebAssembly.Browser/Microsoft.DotNet.HotReload.WebAssembly.Browser.99zm1jdh75.lib.module.js"
    },
    {
      "hash": "sha256-TrJwiUccR1oj/MWbraWJrRWMYum+plXo45TyIgzdpug=",
      "url": "_framework/Funcky.eoahycxpsv.wasm"
    },
    {
      "hash": "sha256-8yKJ741p6VwAV/tXsqreIXnuchAX08yznoCQclwhLNc=",
      "url": "_framework/JetBrains.Annotations.30nyqsrum5.wasm"
    },
    {
      "hash": "sha256-NT9BzKKmKPKpc6Hld2lXcQ9hJ8ZshoJEtcLRjtvyLkQ=",
      "url": "_framework/LanguageExt.Core.v7rodlklwa.wasm"
    },
    {
      "hash": "sha256-q+EkKN9BLcIwLCOVyaecX4eEO6XppOqATijxWzC6otk=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.f7yamg8acn.wasm"
    },
    {
      "hash": "sha256-rk1EVOse3i6uXcKoua15buyKg1mSrNlf2wFTOm2iH20=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.au92kshad9.wasm"
    },
    {
      "hash": "sha256-bOpvG+4/gYauD6qquYzxcfDXNAx3doR5TD2xC2HH6+Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gl9seasc22.wasm"
    },
    {
      "hash": "sha256-b0NoLF7H21exT475itv370PzwHt299S+O7QLL9S0wPQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.9qaxkpf6y7.wasm"
    },
    {
      "hash": "sha256-SlKk2Iszf1CasiPULCl216i2/uWoh0CI0Z1VbByD88w=",
      "url": "_framework/Microsoft.AspNetCore.Components.i180xx2qq9.wasm"
    },
    {
      "hash": "sha256-feTahvOhYuLDIgSFkwXDSewTMyzsM7M9tmjKWEjxeBI=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.begmnasal1.wasm"
    },
    {
      "hash": "sha256-ZS1yaslgZ+MyTPBRGoPsseOOwe4Nvr3XePc58vwXsxA=",
      "url": "_framework/Microsoft.Bcl.AsyncInterfaces.h5iyp9aq8a.wasm"
    },
    {
      "hash": "sha256-DYrTDwbyt3m7me0Lc6JdkjveSLmUZ2fLqs4ICdyJMeo=",
      "url": "_framework/Microsoft.CSharp.j06echzfpz.wasm"
    },
    {
      "hash": "sha256-H/Bfgf0MP/7LYv2KEJTe2yFHdkRe4kJcJNqL5FnO9pM=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.ttbwk6q8rt.wasm"
    },
    {
      "hash": "sha256-rBS3LgUFNuIxbHlU7scSWgQHJj1XvLq5lOCBSE7Xqf4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.sgloa63pwd.wasm"
    },
    {
      "hash": "sha256-kYQHDeicTG+nBEs6l5iq3UmdSMlHJgHqoa+ggaY501U=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.3jwzw3qxt4.wasm"
    },
    {
      "hash": "sha256-rVukgkTLSTNrk72xnW1GjiqXFDoZoeYNJz1CWkpzjqQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.phra2kqghi.wasm"
    },
    {
      "hash": "sha256-kaJEtYTmGmQJ235nthDFz+Ang6Ruk+JnGVFKh9ULJqw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.9udmvturlf.wasm"
    },
    {
      "hash": "sha256-f0r6Qpz7Z6XbqfEQFAKDoC7xxwnPQUeN1uOZN7jQSdU=",
      "url": "_framework/Microsoft.Extensions.Configuration.x8wh4xd62i.wasm"
    },
    {
      "hash": "sha256-cd5Qpyhoa1Mv83WQAMQalR7QZdXdgnBxRIgywoQ5ZXA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.92ulj88j6e.wasm"
    },
    {
      "hash": "sha256-xrrgUG/yk4I9W9bTGoMRs/SFjAwn7XnmpxoWIYskHP8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.qzg75988t9.wasm"
    },
    {
      "hash": "sha256-p1PIrEspjlWTZhuuDFe2zNFctb6Snm3PPP0l1lLRGlM=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.hq61ozpvxa.wasm"
    },
    {
      "hash": "sha256-c5/EPk8uh1q87GmX5HVLC/UUvbz8i1Maljl/W8etqSQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.tgzcelqpkb.wasm"
    },
    {
      "hash": "sha256-BMXU3fj0UK/6PNGpPF3cojEo3DozPCjJGaTZP6GoKdY=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.wbhloeatw3.wasm"
    },
    {
      "hash": "sha256-quilEO0GpuPvxSG6rAylSWEh5TwoCL+XbWNLelEOtds=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.y5k56zvg10.wasm"
    },
    {
      "hash": "sha256-1N2/rCQl/eAmYr1rfjJ32aMFRrX+RN35cCdm1VkbWGo=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.4cqycihgg0.wasm"
    },
    {
      "hash": "sha256-dEjzt1uKX3R6EmoJQrRj6zcO9nfGtBCBS4OOMUzbXIg=",
      "url": "_framework/Microsoft.Extensions.Logging.05o184w673.wasm"
    },
    {
      "hash": "sha256-DyLaldc3Yx7VCPdRhnmmahnWJCCiiecZwizZCXGV2VU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hwa38jh90v.wasm"
    },
    {
      "hash": "sha256-3hHMwTwGq2ENRNRfqbteu11Ql89oGCOOA4qTO1UQ51o=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.qltknulxmy.wasm"
    },
    {
      "hash": "sha256-E0WLcJMfFpM5V2X8uzMGIJ0/0qoBDlhf/RXljHRcX98=",
      "url": "_framework/Microsoft.Extensions.Options.zsk78mkyl2.wasm"
    },
    {
      "hash": "sha256-57hl1S9rfSf1Z3Pq4unXknqN1SSqk4SYsCXrYFVhrt0=",
      "url": "_framework/Microsoft.Extensions.Primitives.51b5spqlwz.wasm"
    },
    {
      "hash": "sha256-qT2aydmmggG8gBaHWUzvrKumK7J9YbGwyd9zdEVWZcA=",
      "url": "_framework/Microsoft.Extensions.Validation.vibclmvzbq.wasm"
    },
    {
      "hash": "sha256-EQfaQose2do/RGDJFP6YWTTeOWA2gufnJurZZZh2XLU=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9udcqny0aq.wasm"
    },
    {
      "hash": "sha256-ZMDJB7HAUuoLzQZRYnLkvVVaR0Aqx1O070OL2H0APzs=",
      "url": "_framework/Microsoft.JSInterop.kksrzpvoig.wasm"
    },
    {
      "hash": "sha256-pz6Nq08pgLqbsP2d/Jn4EFsCe3gNpmHaap/Zxew/JK8=",
      "url": "_framework/Microsoft.VisualBasic.Core.h2kvac5o7p.wasm"
    },
    {
      "hash": "sha256-L2/WuM5KkmRbktqVoNgIFexMJisncaLvtkuDyqHbwO0=",
      "url": "_framework/Microsoft.VisualBasic.r1r1o64guk.wasm"
    },
    {
      "hash": "sha256-f6u/slPHfUjszv2EKsm2fQEKmmrPVH8VNUQjUGPmXh8=",
      "url": "_framework/Microsoft.Win32.Primitives.5nko60lje3.wasm"
    },
    {
      "hash": "sha256-AxfLjbMc5l3NIsQdGtMX2fZ2hj+n1lFgIFBCEqrhUSU=",
      "url": "_framework/Microsoft.Win32.Registry.lmhf2szmg9.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-WCKOYA2YtDnAN7IAFl5YcjL7y7WXf/oZck8MFDEyE9o=",
      "url": "_framework/Polygon.4pyk5zyxcn.pdb"
    },
    {
      "hash": "sha256-eW1ns0ksk1cydh/tqfU66lQY9I0gqXEGg/XSS/ki50o=",
      "url": "_framework/Polygon.dbuwo1teig.wasm"
    },
    {
      "hash": "sha256-6NTPYNI6n3oO57u2wa7lzDTHPFL2ZX2i25hpw7j7xDU=",
      "url": "_framework/System.802vhulao5.wasm"
    },
    {
      "hash": "sha256-/K8wKW5wf0vwTAjJqN2YhR0Sr8RxibLeyVmlwIrdDnA=",
      "url": "_framework/System.AppContext.c2z2iszv5a.wasm"
    },
    {
      "hash": "sha256-IaL/kK1bEI/zWHYYy6XTumLTMCx6U3QnzAN0ZhZvTxk=",
      "url": "_framework/System.Buffers.jv7wyzqgeh.wasm"
    },
    {
      "hash": "sha256-JF1S6+O5rd//jR63yXjT8jzeJVLYhtC6Iomazyu+46Q=",
      "url": "_framework/System.Collections.4u69gysy90.wasm"
    },
    {
      "hash": "sha256-0g6gWUQT/CM0STTkeMNDh/k58TERdqnV/u5BUiPgoX4=",
      "url": "_framework/System.Collections.Concurrent.qyjrh4n7wg.wasm"
    },
    {
      "hash": "sha256-Tl4vPbIwiBiOanNfgKpIHEH8LHbkjhFdjVJhG1AZBwE=",
      "url": "_framework/System.Collections.Immutable.6nfqc1y6mx.wasm"
    },
    {
      "hash": "sha256-QCr/0s0flwGA/GCqLAAE4ON6WmVO491cSonE3bQ9IGc=",
      "url": "_framework/System.Collections.NonGeneric.oye06xq4bj.wasm"
    },
    {
      "hash": "sha256-to5p9xGZUq477KGEDpIfH3UJ4lPoeUNmxWJF1hYQL2E=",
      "url": "_framework/System.Collections.Specialized.ua3ga4ojzm.wasm"
    },
    {
      "hash": "sha256-p1Lg6ia7+B8luWLdv25XkpevVOWp7kEpoW2ZG2JU4Sk=",
      "url": "_framework/System.ComponentModel.Annotations.fu60omoy5j.wasm"
    },
    {
      "hash": "sha256-ZbQnUZmK7uOo5/7/OCDfEd4S+BUVzb13F3kfSTUvfgI=",
      "url": "_framework/System.ComponentModel.DataAnnotations.b05dlz1h33.wasm"
    },
    {
      "hash": "sha256-FopipCTTK1t50cVaouVGtVdvMDrIYyDoG/qzjV47ue8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.6se1ltc450.wasm"
    },
    {
      "hash": "sha256-P5ZvpWHH91ux6O6bOf8ynbRnw5AaIbR8pQvQvhfbFo4=",
      "url": "_framework/System.ComponentModel.Primitives.lzg3p2fcb8.wasm"
    },
    {
      "hash": "sha256-D8pzZSwPMue+ZyITZ+ZAEMWcn+uefBsXKBH7sYN/4mY=",
      "url": "_framework/System.ComponentModel.TypeConverter.pua8doket6.wasm"
    },
    {
      "hash": "sha256-YiKSA3c6DrWeQhnULB8W3aNEklFWk6nMq9LHXQIFBaQ=",
      "url": "_framework/System.ComponentModel.u8ypsaemfu.wasm"
    },
    {
      "hash": "sha256-UNfMOINEZ4FKag9zZIx6s3h7ns5SfuugmXwU+8U/dV0=",
      "url": "_framework/System.Configuration.gkfiw2lgu6.wasm"
    },
    {
      "hash": "sha256-+a1me9l0qxQGQ21ZOXMg91hkMyWZWgMzJoKTxtGafRQ=",
      "url": "_framework/System.Console.p023t1evip.wasm"
    },
    {
      "hash": "sha256-N9SdhWyXlYrOsCF5r1Vdj2MX24SEPjfPHpsXTqmOzHM=",
      "url": "_framework/System.Core.lhxt5qhoq6.wasm"
    },
    {
      "hash": "sha256-RglA8/aUDu9A4xuejyzC501sqvNsZuPchDnUaXO0EoI=",
      "url": "_framework/System.Data.Common.eqtn3ssyme.wasm"
    },
    {
      "hash": "sha256-eQIbLxxsxeL42w74Tq/lXDmF0ynV+bgglc9X+0XLh28=",
      "url": "_framework/System.Data.DataSetExtensions.zp6ucti1as.wasm"
    },
    {
      "hash": "sha256-nWAc+7AFH58HVBr63YYPxWNMbLGtKSZNmjfX75a4Fmk=",
      "url": "_framework/System.Data.d0h61hksxr.wasm"
    },
    {
      "hash": "sha256-fdLLIl/XKyAES/Vpsgv7XkMogMCDODrLHBZBAfQy15Q=",
      "url": "_framework/System.Diagnostics.Contracts.dck23rphvl.wasm"
    },
    {
      "hash": "sha256-dYjxHogP1J8fV6xyYPGZ+6N29+038atjxy+0Bx4JygY=",
      "url": "_framework/System.Diagnostics.Debug.xp56ua2jd2.wasm"
    },
    {
      "hash": "sha256-YKhoNGFx1V1QFffrc8nzwFtpzeQwU8GsVMySyZvpbBI=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.kzyp7dz13i.wasm"
    },
    {
      "hash": "sha256-KMj0UcwgkXCf1ylB6JWKzvV9OUW0NugjW1ZJh7Ev4wM=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.8kwccfatn9.wasm"
    },
    {
      "hash": "sha256-203JmtZD8wfzBSkTfUfU1GHb9AyLbbSygVRZO+TiCGs=",
      "url": "_framework/System.Diagnostics.Process.pbsvhgaqld.wasm"
    },
    {
      "hash": "sha256-vpLMKyIWA7x2n0Bsz9K5HoZ3ngjJ5NBCclrORmE+KmY=",
      "url": "_framework/System.Diagnostics.StackTrace.uosmk512ff.wasm"
    },
    {
      "hash": "sha256-87AUYe4ysxcD0ko7e2ObnrEn5x+SPXaUAbeXhUY8dVE=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.f9a4ca75f9.wasm"
    },
    {
      "hash": "sha256-z7lmrHX9vDxaWhlz1lbKVpvZ513Fb+Xw+Yl6rSiIu1M=",
      "url": "_framework/System.Diagnostics.Tools.r58uhp06u4.wasm"
    },
    {
      "hash": "sha256-tw/FLt5S2lY4KXfUy8nBDyqwj+zk5Xs7JIwpidOmM3U=",
      "url": "_framework/System.Diagnostics.TraceSource.74aa6mybdk.wasm"
    },
    {
      "hash": "sha256-1hZcocCbG0k/cE7HL5GHqzn/H5LAIqsRXDl76joHsu4=",
      "url": "_framework/System.Diagnostics.Tracing.uyjvspoaee.wasm"
    },
    {
      "hash": "sha256-Akl3hiSkdbtaYYGIoYUjeyO//SKuN+iBRcgkxNYT8BI=",
      "url": "_framework/System.Drawing.Primitives.ygagw4cllm.wasm"
    },
    {
      "hash": "sha256-r5E4jlAN3MoHR7CGVqYY7c6SjzbU0tOKOpK6HyHNpHo=",
      "url": "_framework/System.Drawing.nem9gi6fos.wasm"
    },
    {
      "hash": "sha256-SK7Rp1LlZeCM4aF9xv3+qB0GzGj4W3z9v+xSAyAtJpI=",
      "url": "_framework/System.Dynamic.Runtime.4xdpjnpw4n.wasm"
    },
    {
      "hash": "sha256-tSKaftmE+6oibzbPJ8RrVystM3q+Ig9vv2UIM1vbTZg=",
      "url": "_framework/System.Formats.Asn1.9bedxuqoe2.wasm"
    },
    {
      "hash": "sha256-vcSKSfY4GCt79AW+Ou0PNWaEeLaiDIHi9/sJdJG/az0=",
      "url": "_framework/System.Formats.Tar.hjwgs8goh9.wasm"
    },
    {
      "hash": "sha256-ovUiGEaI708wBPkNBqnhJVjOtfJshPLtPAdk7IDq5rE=",
      "url": "_framework/System.Globalization.Calendars.qqu4d9h6d4.wasm"
    },
    {
      "hash": "sha256-RbJFSGZfQU4dg7vZg0hOydbRGKGj7YgE6K/M7kwEnTo=",
      "url": "_framework/System.Globalization.Extensions.1d3dstrmml.wasm"
    },
    {
      "hash": "sha256-K1lyyFLkCJLd5yY5976WrfLBIWlM+Hp7rXpC+0X82T4=",
      "url": "_framework/System.Globalization.de5yfe377i.wasm"
    },
    {
      "hash": "sha256-VLJMKsqb/ahJC6wdMLIpzC3Ba17pMreLo6ABr2YaEBs=",
      "url": "_framework/System.IO.Compression.Brotli.s6yhzy6ra0.wasm"
    },
    {
      "hash": "sha256-wPZuicWgYn53ZKpeG8rgTlzL30S6iVFUWgN/R3Pghjo=",
      "url": "_framework/System.IO.Compression.FileSystem.8e8pwcj0r8.wasm"
    },
    {
      "hash": "sha256-s4TtJcgT9w/91UL6CaceheKsChluKLRbOOzm10/qiPs=",
      "url": "_framework/System.IO.Compression.ZipFile.5ulbwi9soi.wasm"
    },
    {
      "hash": "sha256-svN92AT3+BUYa1QtkLdk9RMxfI+zkBH7DiarN69nu6I=",
      "url": "_framework/System.IO.Compression.mbpybl62de.wasm"
    },
    {
      "hash": "sha256-NF0+/VKsfVj0BiivY2UYtXKZFBqBjDpoBTziEp9WRdQ=",
      "url": "_framework/System.IO.FileSystem.AccessControl.olg38ln9cn.wasm"
    },
    {
      "hash": "sha256-ACjniuh1mOYJ8DzDXvcOxpfo62cJGJdVS9lPK3J84Ow=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.0o22a9akm7.wasm"
    },
    {
      "hash": "sha256-tj/OX0gw97/4j/xmnlepeUlLWa2vb1CncREZ/y2oCkg=",
      "url": "_framework/System.IO.FileSystem.Primitives.efika37m4r.wasm"
    },
    {
      "hash": "sha256-u4elZM62YqQW3aOIkBuyqtG2dh22Q/OLxHP7mNgKbo0=",
      "url": "_framework/System.IO.FileSystem.Watcher.b81ylq3lid.wasm"
    },
    {
      "hash": "sha256-1qzBK4xFdn4wzMHICchwvCbGMOaqQNcgqsp3SRJOMKE=",
      "url": "_framework/System.IO.FileSystem.m0wrikzu53.wasm"
    },
    {
      "hash": "sha256-hr+g8mbenPBU+e6Fnd1AgxfXkWXkTHBNTMdZ9HBNeH4=",
      "url": "_framework/System.IO.IsolatedStorage.moxgx46g2v.wasm"
    },
    {
      "hash": "sha256-qXWhYhgIDyR7MQYlvG9cZ95TJXrGjK7ertrH0WHYCIk=",
      "url": "_framework/System.IO.MemoryMappedFiles.1qwcduyngl.wasm"
    },
    {
      "hash": "sha256-OEtaHHhbPrV24wsVnhfA4PbJntaPbb7+igynNVvFXxw=",
      "url": "_framework/System.IO.Pipelines.8cw6ik4s41.wasm"
    },
    {
      "hash": "sha256-9hUXtJqrWjPe4aLq89Wp/LlIBv8q7oqbRwEST0BqreM=",
      "url": "_framework/System.IO.Pipes.AccessControl.yejz5yzur4.wasm"
    },
    {
      "hash": "sha256-Zr2cBhgS1wyjPdmHBK+VVgSbfY/odwPWe+PMnA4Bi24=",
      "url": "_framework/System.IO.Pipes.aovxgtgqh6.wasm"
    },
    {
      "hash": "sha256-hEk9jPa+QsFOE4mODDFbZMUMh9Cza9D7VM3J8ezXr8o=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.09whssgw8a.wasm"
    },
    {
      "hash": "sha256-UxqjUSSEz7LfKGInDukxFxC8WIX5WFCauNNBghLtXGc=",
      "url": "_framework/System.IO.lavhpdycer.wasm"
    },
    {
      "hash": "sha256-Hr7vFko1NtsUNvFMsGKF3gcQ46evU8eeKeO5DWdnYww=",
      "url": "_framework/System.Linq.AsyncEnumerable.a9leffpn15.wasm"
    },
    {
      "hash": "sha256-fwD/0YGVA2NtmzaB3kmK1VBquX5rCHs7Pgr8tQKKNUA=",
      "url": "_framework/System.Linq.Expressions.r1c6atm1cw.wasm"
    },
    {
      "hash": "sha256-HL5m9ysqEVBiWOWsjxG6x1/p8Ax6i6HNxP1p2JK30vE=",
      "url": "_framework/System.Linq.Parallel.g7xw2v7b07.wasm"
    },
    {
      "hash": "sha256-oGsvMGIFjxOinjBMGMfoREtSuPfmSm6a1qephV4cDhE=",
      "url": "_framework/System.Linq.Queryable.sdb7n2mhn5.wasm"
    },
    {
      "hash": "sha256-Ndq91UdOaePUPruH0XwhG8EfY9zHI9VjSDvaHyrU62A=",
      "url": "_framework/System.Linq.rskygq9p37.wasm"
    },
    {
      "hash": "sha256-QignbHihp8N/AHJbFxGSaKTTwip5OG1Ex3Xu+gnPd8o=",
      "url": "_framework/System.Memory.i4ezuafn9k.wasm"
    },
    {
      "hash": "sha256-tDtlMI5NKjn1XCfxKn4u4kEb1f7ViQlCo34kX8VCJV4=",
      "url": "_framework/System.Net.4qaklzza4n.wasm"
    },
    {
      "hash": "sha256-q+fbtqH8Ng0VVrmZigvxi1DiYMOcGhwA9QYooGSkb24=",
      "url": "_framework/System.Net.Http.Json.zy8lvi4mlm.wasm"
    },
    {
      "hash": "sha256-MEXCxsa4MHoKtsmQYOJNqQiV2BIWopYdC7DQAcKxqy0=",
      "url": "_framework/System.Net.Http.c5n0c1iaa3.wasm"
    },
    {
      "hash": "sha256-t2kK/4r7DO5hZBFT38HSNlvyi8bwkHV6MxF5EToXbg4=",
      "url": "_framework/System.Net.HttpListener.bzgrr803nf.wasm"
    },
    {
      "hash": "sha256-OaHyLRif055DU7n1jjKgzLZz2s4XjRs5BX4fo39CeKU=",
      "url": "_framework/System.Net.Mail.tbh6kodhoc.wasm"
    },
    {
      "hash": "sha256-+0hB6vvHz/671Jf4yfKkXFKjse15zC/Kf7s9XE8ale8=",
      "url": "_framework/System.Net.NameResolution.97kbgrqa3x.wasm"
    },
    {
      "hash": "sha256-JvIohIRZGlm/+IxsnPZKZ2Ps44BKVprgwehALa5th0g=",
      "url": "_framework/System.Net.NetworkInformation.6lqpzaxhm8.wasm"
    },
    {
      "hash": "sha256-kCXBIumyAHTtmm6vl2ZAhfXG2/Q1Tb1OqgZzuepbLg8=",
      "url": "_framework/System.Net.Ping.8imioclqo5.wasm"
    },
    {
      "hash": "sha256-mHTKctintC1Wr9bR2ybPWGP8FXBiTehna1X3kNymSTs=",
      "url": "_framework/System.Net.Primitives.06opecf70b.wasm"
    },
    {
      "hash": "sha256-JnAa5r/lZUsfFU7li/jbjq0LspPunJDrbDZItl6n5cI=",
      "url": "_framework/System.Net.Quic.m8fkmwx2e2.wasm"
    },
    {
      "hash": "sha256-sx8DBBYz/YFyK8b5r7vawbecA384e7zEKd81zD94Kkg=",
      "url": "_framework/System.Net.Requests.r215bg21jb.wasm"
    },
    {
      "hash": "sha256-czeQag0zUvoNd+LIdV4jcMs47Y1Ek6CF0S+6ZaLpgLA=",
      "url": "_framework/System.Net.Security.7zwmva046j.wasm"
    },
    {
      "hash": "sha256-ROnnbLvTNWDOeScUlG9SDwLxvaz38ABUwVEyAnEGDic=",
      "url": "_framework/System.Net.ServerSentEvents.c4uhw1iihb.wasm"
    },
    {
      "hash": "sha256-5U313KmkSiOeCy+3brWCNcNtrt07brFNf+gVYCR2y4o=",
      "url": "_framework/System.Net.ServicePoint.jysyz6pe5n.wasm"
    },
    {
      "hash": "sha256-CY0MZ/+/k1OP+ZBjSWtjGWJQxLuMkT7Ag7QVXVzBAec=",
      "url": "_framework/System.Net.Sockets.3pbfy2myku.wasm"
    },
    {
      "hash": "sha256-vKb16TQRF7NY7cSvnqIuYbT3cwV/+Y3xq2MpHIUwAoU=",
      "url": "_framework/System.Net.WebClient.0vydlgc6dw.wasm"
    },
    {
      "hash": "sha256-ydnCzipG3Q/N6B8l/i5+ICyls+k47V9X3XJhISGlqhs=",
      "url": "_framework/System.Net.WebHeaderCollection.7o9dkw6pk7.wasm"
    },
    {
      "hash": "sha256-dVRFFC8RdqOlzWEKQpG0pM85PFfc2OY2lJuTKNFwy+s=",
      "url": "_framework/System.Net.WebProxy.zmhtx343lv.wasm"
    },
    {
      "hash": "sha256-DkeBT1Pg0REE1NZFjxAer1/vHdWNMGpENDo5wgI3x/8=",
      "url": "_framework/System.Net.WebSockets.Client.2f3nip0afr.wasm"
    },
    {
      "hash": "sha256-COiKH5sQr3MEOfCnC1RPormfSS7HlT4P9KCaOSN3pHU=",
      "url": "_framework/System.Net.WebSockets.gm6qkoxxpi.wasm"
    },
    {
      "hash": "sha256-TSkQpffIW+0zm/VKS4iCUtr12Y6732xH89JbymLfA58=",
      "url": "_framework/System.Numerics.Vectors.95xmo86x7v.wasm"
    },
    {
      "hash": "sha256-YsucGbZIhglan4Dr05M68J3wsVbeIVnY92h5eaM/274=",
      "url": "_framework/System.Numerics.ig9uomhcbs.wasm"
    },
    {
      "hash": "sha256-qGPud04AIksV++yyYF0zE7gjmIhe9Uhr+Sjb9thAKXk=",
      "url": "_framework/System.ObjectModel.snprhmugxx.wasm"
    },
    {
      "hash": "sha256-UPqXyIy+Vhy/9g3REe6SNZ90Yu2D6FU+kG6v4KTNqkM=",
      "url": "_framework/System.Private.CoreLib.8ubjv9s18t.wasm"
    },
    {
      "hash": "sha256-nCwGk+1Ei8db+rRyBbYVMjE7Oe0wZr9w2geHJQnLjn4=",
      "url": "_framework/System.Private.DataContractSerialization.gjeod45zn6.wasm"
    },
    {
      "hash": "sha256-K/hRKjzMbXcgQmquOqff8l5abAM0bDpYZ8giwo1sCKo=",
      "url": "_framework/System.Private.Uri.z6jswaywn8.wasm"
    },
    {
      "hash": "sha256-D4/MIhb7PTDq4/+ra0e15LQlIwbeGuH3ksedF/AoWdo=",
      "url": "_framework/System.Private.Xml.Linq.lr5v2oiugs.wasm"
    },
    {
      "hash": "sha256-5KJf/3xcuGV17lJVCiiCw7s1tZCl5+ELHZcRbzTIbwM=",
      "url": "_framework/System.Private.Xml.wtrgu5mtlc.wasm"
    },
    {
      "hash": "sha256-chZ/GwGqUZFjMR0NhbxhI2t+O5fGcWuV+gRP6QnhP94=",
      "url": "_framework/System.Reflection.DispatchProxy.upd872z9tl.wasm"
    },
    {
      "hash": "sha256-PGh2/6TE8aEWRk894ZlBzhFNtpU6vjPZFpMqKapq6QU=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.g7zocluvg9.wasm"
    },
    {
      "hash": "sha256-vYIhnzkf5Ag/eg+Xd0JuR1JIrBYrmiKTGKqO5M+zgcU=",
      "url": "_framework/System.Reflection.Emit.Lightweight.dg35e9lw3s.wasm"
    },
    {
      "hash": "sha256-zmBwIoocMYbTptjU2gbRUIXz07dHxbt5rvVVCFB4J0s=",
      "url": "_framework/System.Reflection.Emit.mrh9tkt04t.wasm"
    },
    {
      "hash": "sha256-xEDQsF0JAVGHiP0UUg8LNZkicpuJyj0QcGhSkWNPWqQ=",
      "url": "_framework/System.Reflection.Extensions.sognfb51go.wasm"
    },
    {
      "hash": "sha256-eD2DPloi86p0ROVFzHbfNZU6e1Ly4TPMdr2iBuImEk8=",
      "url": "_framework/System.Reflection.Metadata.4temtjmiid.wasm"
    },
    {
      "hash": "sha256-76KnuMlYrRFKgG/vaQBzaWHr3pPtfGKM8+eL1OpSAXw=",
      "url": "_framework/System.Reflection.Primitives.rla5yzpm68.wasm"
    },
    {
      "hash": "sha256-mswpR2Zal1E7ubdSBCH9NU1CPNl9LhK5psIDlRtgXDA=",
      "url": "_framework/System.Reflection.TypeExtensions.eziqyy81b1.wasm"
    },
    {
      "hash": "sha256-EZal90o5b8F2uy8AlM8torrALvU1eKTb8KHgX2rajag=",
      "url": "_framework/System.Reflection.d59jdh5una.wasm"
    },
    {
      "hash": "sha256-3KDhYHgXLUBc83+iLovVRwuxIBNkfu1Mv7yQ9SVJhfo=",
      "url": "_framework/System.Resources.Reader.42xaf3wy3o.wasm"
    },
    {
      "hash": "sha256-eTBjOO6rYoSrzx9S9Dv358zJKDWMTVrLjwCpRPqNhFs=",
      "url": "_framework/System.Resources.ResourceManager.78ixpnkxwz.wasm"
    },
    {
      "hash": "sha256-50HY5j2XCtRweQ6f5k5xWEQWT9o5UhvyMvmHrj1q6zk=",
      "url": "_framework/System.Resources.Writer.j5qafotg8o.wasm"
    },
    {
      "hash": "sha256-NCqP7cLbmnc7ZJCoxAISLDvqyJqjOg+/Ue2kC+Yx6QU=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.4s8vka7mb8.wasm"
    },
    {
      "hash": "sha256-xfRptfAquSCUgY2jjpM0ZeX6PM7BoMnh9WRSKipy3H8=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.7dilrkv0n5.wasm"
    },
    {
      "hash": "sha256-hb139LM7Fg4fQ1OzSrbW1cmZB2Kev/7F9Jj/OKPKXYA=",
      "url": "_framework/System.Runtime.Extensions.x9isqqr7mp.wasm"
    },
    {
      "hash": "sha256-yKnNECFRT1B9euhzjT/5dSC1sJUoPfO6m2qkDLeGTYQ=",
      "url": "_framework/System.Runtime.Handles.gmejdz8b1i.wasm"
    },
    {
      "hash": "sha256-KDEGwvLuPsW2U5IWosNGLuFfvvsnc51nttHvW1jBuyQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0uujcsvtme.wasm"
    },
    {
      "hash": "sha256-u39o0cpKkndMdK/4OyAxy+2qkc9PGw9H8JLbVLnx6pI=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.zydo3g4f27.wasm"
    },
    {
      "hash": "sha256-+on+uh3ABzIz7NaS0i3xbt2cIpDyhUT0y5JlJO/X84Q=",
      "url": "_framework/System.Runtime.InteropServices.y2d70ja2cw.wasm"
    },
    {
      "hash": "sha256-tE5pijLzITXr2GNazqJfMxf/cUQnh4DpPpvrwXi+o3w=",
      "url": "_framework/System.Runtime.Intrinsics.kmq2apj5l0.wasm"
    },
    {
      "hash": "sha256-x91aidPCMaoWyaRMIgxW6p2d28VwkIuUBlypTqGceFw=",
      "url": "_framework/System.Runtime.Loader.3t71kb21wu.wasm"
    },
    {
      "hash": "sha256-N1Fe+j6anuFpO55l0zkEtjQMhoNxz2zleDCPbup1XpY=",
      "url": "_framework/System.Runtime.Numerics.n8gwbfvruj.wasm"
    },
    {
      "hash": "sha256-aOsZY3nMr6z32t39pJR69/VMnGxeJzvEp0ETnxT3GmU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.kp04s3jyn3.wasm"
    },
    {
      "hash": "sha256-zDYl84jM9auaAgtHUHoZJ6GTVRwa8WxsQMlBos7yZfw=",
      "url": "_framework/System.Runtime.Serialization.Json.w5ytzloqtn.wasm"
    },
    {
      "hash": "sha256-ONCren6sSBH/S6Lrdi02lcm7BEyEsrvDdhedXaPwX/M=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ktqshul6zq.wasm"
    },
    {
      "hash": "sha256-p/WuCRmCujQfBUCe4wtQXRR9XcMzz2c0hWt7H+38DuI=",
      "url": "_framework/System.Runtime.Serialization.Xml.zxalj6oi7a.wasm"
    },
    {
      "hash": "sha256-MDKNYDBRCcTlV03EhLQLZbSeoFY+kI8U+lAU/viuNF0=",
      "url": "_framework/System.Runtime.Serialization.oqtdyhn9ex.wasm"
    },
    {
      "hash": "sha256-ZDVnvJqlmlCfxYjN5fr+P0doPw46WTWaXRLcW5YRFIk=",
      "url": "_framework/System.Runtime.csube7l7j7.wasm"
    },
    {
      "hash": "sha256-cU4IfLEkqllRw6droSxGbz3BUtQJHP8L8QwTGK58P40=",
      "url": "_framework/System.Security.AccessControl.l725whzq2q.wasm"
    },
    {
      "hash": "sha256-O8tZsGr7ds++haAS+cf0wwHgax+RlcRNgoOk38EyR/o=",
      "url": "_framework/System.Security.Claims.ls4mvh9izv.wasm"
    },
    {
      "hash": "sha256-dXe3LsqJ1vNr/WFRatELAVLh1CP2PwfQXASDrSfunAg=",
      "url": "_framework/System.Security.Cryptography.Algorithms.xptci9gx2e.wasm"
    },
    {
      "hash": "sha256-7LgAp+0po71GWfP8ZuvRYIyjsF1gHKZJ3352ulzjb/0=",
      "url": "_framework/System.Security.Cryptography.Cng.cwmo3bkk7r.wasm"
    },
    {
      "hash": "sha256-gbvQ/uAStjISX/CISFTZj9Rjbcp1BewADcXCef0QV5E=",
      "url": "_framework/System.Security.Cryptography.Csp.dh1ommb4jg.wasm"
    },
    {
      "hash": "sha256-MvT0VFnceq8eJcNM1q/yclUNhjtcKfZ1sq+1yOY8Qqc=",
      "url": "_framework/System.Security.Cryptography.Encoding.mjrnxqi695.wasm"
    },
    {
      "hash": "sha256-VQArOf/OSDP6hdRPrFn8/6yG0/OY3DkjZETENRIvKls=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.bwa2csm6hl.wasm"
    },
    {
      "hash": "sha256-BQ6O6oEE2uisVe5cYv2pXq2W+3Au0Mreg58sBuPdp00=",
      "url": "_framework/System.Security.Cryptography.Primitives.3u8l6vjobk.wasm"
    },
    {
      "hash": "sha256-h4O+YpHSawujBDPC6VIgdrvFG/DwhmLtKQWaWrPvffQ=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.ha8unomn85.wasm"
    },
    {
      "hash": "sha256-QJpzemleE1G7DoWqPxhIsz0VGQ39onjjkxCZIBSAgWY=",
      "url": "_framework/System.Security.Cryptography.k3w9v7ue50.wasm"
    },
    {
      "hash": "sha256-GhgxN265Hnrb++RANZUp/PjjUmCHd5q+rju9sFLStyg=",
      "url": "_framework/System.Security.Principal.60u8ec2sxl.wasm"
    },
    {
      "hash": "sha256-GU8SeAu2VYxmSyTNbCKkx7Prg6hGGp1JclbRo9lnbiU=",
      "url": "_framework/System.Security.Principal.Windows.xecxe1aqkj.wasm"
    },
    {
      "hash": "sha256-dhu3HwNFqdM6H4nln0ILjPR8bh9H+zMFMy3ajbl5TEs=",
      "url": "_framework/System.Security.SecureString.eim2t43py4.wasm"
    },
    {
      "hash": "sha256-W4rsIX/JstFGb9BuFPEshwSqlqbmaZHYNrF7aRxYggI=",
      "url": "_framework/System.Security.n9s9f533o4.wasm"
    },
    {
      "hash": "sha256-kBbb3QDrvSCgSerndOm7zlCCo4AANOUw3EoJ4bWO6p8=",
      "url": "_framework/System.ServiceModel.Web.0gnfditp44.wasm"
    },
    {
      "hash": "sha256-cj8Q4z7X9AoM9eqcJgDEGh/Y0+3tCS3i1WjuODB39Uw=",
      "url": "_framework/System.ServiceProcess.isfmih530m.wasm"
    },
    {
      "hash": "sha256-OuzhS1UJERfXfxJNFeB90xsx3+ZVkGOpXrDCXAKrirU=",
      "url": "_framework/System.Text.Encoding.CodePages.uujl0fau9d.wasm"
    },
    {
      "hash": "sha256-srV09G1PP9FVqF0aeuMZJq06N4tct5hcZ+CwpuqhqxY=",
      "url": "_framework/System.Text.Encoding.Extensions.mr1rkcnv13.wasm"
    },
    {
      "hash": "sha256-MLyR55YLzFGLmUJhYXAgL1eSlVsoLM9DZ9AF3yjHjek=",
      "url": "_framework/System.Text.Encoding.g0sgi8atoh.wasm"
    },
    {
      "hash": "sha256-TkUE2WeUuuig9GrdHEkGpl+x/jBXcGm7808V2hVagOo=",
      "url": "_framework/System.Text.Encodings.Web.mb9atwjqsn.wasm"
    },
    {
      "hash": "sha256-5RTaN0JxaGJllfLtZwuEDWQg9xaBZGpF+tIrpPlkdTc=",
      "url": "_framework/System.Text.Json.hphxl2km4u.wasm"
    },
    {
      "hash": "sha256-AqWnwO3chHjgXyNSmYw2kuDbdhDPsnvczcm7WMD62i8=",
      "url": "_framework/System.Text.RegularExpressions.6a9cxw2dq7.wasm"
    },
    {
      "hash": "sha256-9oC+LgyLlyfh/dxbG4/74EmhJnjGL8b1pOxfyvTMpwo=",
      "url": "_framework/System.Threading.AccessControl.m54ktoxm2s.wasm"
    },
    {
      "hash": "sha256-I6Ic+FPml+Z8jhdiwJXYiv/Ai1yAyc5I3kqF4r0JrAY=",
      "url": "_framework/System.Threading.Channels.v1qpu5ozcz.wasm"
    },
    {
      "hash": "sha256-javxIrC+o96lJ4/nvMq/pvpVcgpjQrzd5XH9g9C4u4k=",
      "url": "_framework/System.Threading.Overlapped.jgaekt0s0k.wasm"
    },
    {
      "hash": "sha256-98XOM2TEKDKy4hA9Ti0hd5xbl0h/4ZQ/0P23RwITACA=",
      "url": "_framework/System.Threading.Tasks.Dataflow.tnzumxbiut.wasm"
    },
    {
      "hash": "sha256-+m5PwTeyBG2NOkwZKSnkYQcotGYGm6/TdclnpdFli40=",
      "url": "_framework/System.Threading.Tasks.Extensions.abjpbegqw7.wasm"
    },
    {
      "hash": "sha256-ciLKVq3LBPOvNgR9AdzC4wfh6EEPb+08tCTjpXd5Nks=",
      "url": "_framework/System.Threading.Tasks.Parallel.uopu4j1ll0.wasm"
    },
    {
      "hash": "sha256-r9oq5YYeKRo+Xs1RLyHLlcociyVPcRJiSnJ4lrJUyDo=",
      "url": "_framework/System.Threading.Tasks.f8ooi2bwxq.wasm"
    },
    {
      "hash": "sha256-bgh6805hir/uiGP4SdKhOF7HcW2z/Af4xypRqBAhj/o=",
      "url": "_framework/System.Threading.Thread.icdc9s98z0.wasm"
    },
    {
      "hash": "sha256-pKi/o3tTV4J6JY18/UXmERqG+9Ei9kjCJcsin7SJoOE=",
      "url": "_framework/System.Threading.ThreadPool.sqmy5jnljd.wasm"
    },
    {
      "hash": "sha256-I6/NajKCnP5eXpeMKILLzGttnQ+BmwDAgDWRPRgj8gg=",
      "url": "_framework/System.Threading.Timer.n7hcp5usgn.wasm"
    },
    {
      "hash": "sha256-pRGrYZ78tSeq+9d6cFTCUhRxYJwRGX3dSWCEJb33xSo=",
      "url": "_framework/System.Threading.nxaopq8r9v.wasm"
    },
    {
      "hash": "sha256-auz8FcE2SKFTLameaNOZCiNisRJGnS8bYCHx7haHoIQ=",
      "url": "_framework/System.Transactions.Local.q4k65jbhaz.wasm"
    },
    {
      "hash": "sha256-Nei1TQva4sHGLKlPi/GvdwNdOTUPVfNs405///tsN7A=",
      "url": "_framework/System.Transactions.vnrbvecmwd.wasm"
    },
    {
      "hash": "sha256-blDN8OhZRiSF187D0z1M5o2M5aHP9rxvXIGxv130CwE=",
      "url": "_framework/System.ValueTuple.6b0gmpb390.wasm"
    },
    {
      "hash": "sha256-cAqx0jsCodOgbls9FDyplzXB6ocmboR/yQx/mQSRWl4=",
      "url": "_framework/System.Web.HttpUtility.cxyvb282ci.wasm"
    },
    {
      "hash": "sha256-QvbCXGr8iqtW9AN3b6v8Lzet6LLM33ySfjJ0v1LM1Bs=",
      "url": "_framework/System.Web.aeo7nmvkid.wasm"
    },
    {
      "hash": "sha256-KVE8aUAPPnPmLeWrhqZRqHfx5moeoEoXkZWjXswPO/o=",
      "url": "_framework/System.Windows.brg453rzbv.wasm"
    },
    {
      "hash": "sha256-9ThjkczNOE9N4dDG94cO+MDWKNziO6N71wzXaLcvvrA=",
      "url": "_framework/System.Xml.5s4754zdrc.wasm"
    },
    {
      "hash": "sha256-HzUzg4lR8XskvD/2IthZHe4JiUrSB9NPfzJNKnL1cdc=",
      "url": "_framework/System.Xml.Linq.nmrhj7elbr.wasm"
    },
    {
      "hash": "sha256-A+c69Te7Z6eqB2tvckBdVM5rTy5lfolUwUsGZ0jvpyg=",
      "url": "_framework/System.Xml.ReaderWriter.91p1gp9557.wasm"
    },
    {
      "hash": "sha256-zG6ZkeNKtHZbGyusdUopn9HLcfZYyiG90ZOsAh0WP/s=",
      "url": "_framework/System.Xml.Serialization.ckvc8z5y7y.wasm"
    },
    {
      "hash": "sha256-am11JOmO484uml+v90svFmWD0obrJeQ7lxGBCWOc+wI=",
      "url": "_framework/System.Xml.XDocument.yqi6lt4nme.wasm"
    },
    {
      "hash": "sha256-uzLGbcvk9kZ0baKEO11TpSI93Y5oMrmkaM0mx7Ne0f4=",
      "url": "_framework/System.Xml.XPath.XDocument.3ukl29h35t.wasm"
    },
    {
      "hash": "sha256-6vJuPXqveQAcCnwxUnRUHAaf9JJyKEPRwDdZEDM1utI=",
      "url": "_framework/System.Xml.XPath.mto1j3qx1a.wasm"
    },
    {
      "hash": "sha256-2AMukrRhIuFp1rkDraESwzmZbaqOoa6kz++bxtm3jHE=",
      "url": "_framework/System.Xml.XmlDocument.kp4g8oyokz.wasm"
    },
    {
      "hash": "sha256-V/GIQFT2gkPoQGlXHjLoQ2Yev2nBFSC2tfDXNRKYCGc=",
      "url": "_framework/System.Xml.XmlSerializer.1mt75y9wos.wasm"
    },
    {
      "hash": "sha256-AAqTAi+vgOcStGpiy9Y9e1b6rGzlfaEPdg3wtsG0yIM=",
      "url": "_framework/WindowsBase.8yv9o2iuhl.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-7hn9TsGppaKDpTB48RhdpNjDrSseNWhhE/kcFK02QFQ=",
      "url": "_framework/dotnet.6n1vk27i56.js"
    },
    {
      "hash": "sha256-MmNh2ZcrFN6TZSGHyJD1vSUlL78DpbOz5eo6WSaoHag=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-Jq16DJlsNP/EZy3u5dUfhPu0r4vqciQE3d0LSaelSes=",
      "url": "_framework/dotnet.native.2qba9g5fwn.wasm"
    },
    {
      "hash": "sha256-uQpMf2vCY3ZTY+nV2gmp8VdAe67PW6h1gInkE7r/PLY=",
      "url": "_framework/dotnet.native.xanz2e7ksm.js"
    },
    {
      "hash": "sha256-1OEka2mzL1ydWBMKE7InT+DaMazRfs/Q3YtWISoeRRI=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-82UMflQuWomOXTd29akEcY13QLehNcDOVqIwvKLH/kQ=",
      "url": "_framework/mscorlib.d4fuuhbiqe.wasm"
    },
    {
      "hash": "sha256-qvS8z84YdecQR/SxYISAg7okb66AKCp1kOEtPuat9hs=",
      "url": "_framework/netstandard.qwxk4mrnbx.wasm"
    },
    {
      "hash": "sha256-CsChHlHUYGbuIEdR+5X9lxWNazWkgwxEsDPWRPQmRpQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LIjdTtpkXOuEktIAXfh7nDrLG0ahEoqJyEp+xqMLE/g=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-tcmoPa8qNE+UJ1xb1AsmPmkzZYxT9wBz2GiaFVrE+X4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-r2M7+iwmenszH8XuInuaCzEXQiS3djY/gEHGmYAsREg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-UZeUSOhXCgquRGKz4mk+6FCaIBm7hHCbo6Ypkxf5LMI=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-VrtBtGOVND/Q4EM7dbyqVLpMOEloQA60kbKE1RUiAr4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-HNj9Lv8v7noz1p0ZJvzf/LKZG4YzEDOqPIPwirL0vK8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-cOnSFSyUXXmR9MEzyLwPodOe46YipzaiuUaboSlQnJg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Nch2KoFhcOw/774lzVhPgh7O9gk3ryIsc/il7pR2hfA=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-mrUeAvhmT4HtAnDbtwaRRZIaYj8viXH2eURJeFyLsoQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-EOa0V69tZcnBGsyuPIz9HDG7t0YcjaiyS8IV8B07gPc=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-nJ/uG4jX03fhY62HP+bFDq9+WYnJGVm5y/hS/4YuP6M=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
